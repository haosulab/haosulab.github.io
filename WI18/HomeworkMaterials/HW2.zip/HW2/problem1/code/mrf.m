%% MRF solver that implements "Efficient map approximation for dense energy 
% functions" by W. Leordeanu and W. Hebert, in Proceedings of the 23rd
% 
% W: joint version of all W_ij matrices decorating the edges, as described in P1(c)
% U: joint version of all U_i, as described in P1(c)
% nodes: vector of size (numshapex x num_views), enumerating solution nodes
% iterEigen: number of iterations in power iteration
% iterClimb: number of iterations in hill climing iteration
% sol: binary solution from MRF solver

function sol = mrf(W, U, nodes, iterEigen, iterClimb)
%% your code starts here:


end
