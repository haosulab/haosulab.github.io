%% Skeleton for aligning 3D shapes in P1(c)

%% Convert dissimilarity to similarity
% Your code starts here

%% Build W and U
% Your code starts here


%% Solve MRF from W and U
% Your code starts here


%% Visualize and dump results
% Your code starts here