% P1(a): extract HoG features of input image im
% remember to set up toolbox before you run this function as below:
% PATH_TO_TOOLBOX = ''; % place the path of Pitor Dollar's toolbox here
% addpath(genpath(PATH_TO_TOOLBOX));

function feature = hog_extraction(im)
%% your code starts here

end