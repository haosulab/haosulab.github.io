% P1(b): compute pairwise dissimilarity matrix between two models.
% feat1, feat2: each being a matrix with V rows and H columns.  
% Each row corresponds to the hog feature of an image.
function D = pairwise_dissimilarity(feat1, feat2)
%% your code starts here, output a V x V dissimilarity matrix


end
