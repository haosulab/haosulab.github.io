%% Skeleton for shape labeling in P2

% Set a path to a directory where you stored features from feature.7z, and use it in your code
PATH_TO_FEATURE_DIR = '???';

%% Choose a shape class class to work on and create a train/test split
% Your code starts here


%% Load and organize features vectors and labels for training, visualize the training set
% Your code starts here


%% Train a classifier
% Your code starts here


%% Test a classifier, visualize the results
% Your code starts here


%% EXTRA: train additional classifier and compare its results with JointBoost
% Your code starts here


%% EXTRA: solve pairwise MRF using graph cuts 
% Your code starts here